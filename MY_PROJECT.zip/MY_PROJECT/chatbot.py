def chatbot():
    while True:
        user_input = input("You: ").lower().strip()
        if user_input == "hello" or user_input == "hi":
            print("Bot: Hi! Nice to meet you.")
        elif user_input == "how are you":
            print("Bot: I'm fine, thanks!")
        elif user_input == "what is your name":
            print("Bot: My name is Python Chatbot.")
        elif user_input == "what can you do":
            print("Bot: I can answer simple questions.")
        elif user_input == "bye":
            print("Bot: Goodbye! Have a nice day!")
            break
        else:
            print("Bot: Sorry, I don't understand that.")
chatbot()